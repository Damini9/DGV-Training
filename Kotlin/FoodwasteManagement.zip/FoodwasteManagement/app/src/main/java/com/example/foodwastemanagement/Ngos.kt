package com.example.foodwastemanagement

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Ngos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ngos)


   // getting help button to go to activity DoanteFood
        val helpbutton = findViewById<Button>(R.id.helpbutton)
        helpbutton.setOnClickListener {

            var donateFoodIntent = Intent(this, DonateFood::class.java)
            startActivity(donateFoodIntent)
        }
        // getting requestfood button to go to activity RequestFood
        val requestFood= findViewById<Button>(R.id.requestfood)
        requestFood.setOnClickListener {
            var requestFoodIntent = Intent(this,RequestFood::class.java)
            startActivity(requestFoodIntent)
        }
    }
}