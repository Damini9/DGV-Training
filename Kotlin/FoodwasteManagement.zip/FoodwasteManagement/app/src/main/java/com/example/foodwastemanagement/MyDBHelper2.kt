
package com.example.foodwastemanagement

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class MyDBHelper2(context: Context) : SQLiteOpenHelper(context,"USERDB2",null,1){

    // getting override functions fo database

    override fun onCreate(db2: SQLiteDatabase?) {
       db2?.execSQL("CREATE TABLE USERS2(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,ADDRESS TEXT,PHONE TEXT)")

    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }

}
