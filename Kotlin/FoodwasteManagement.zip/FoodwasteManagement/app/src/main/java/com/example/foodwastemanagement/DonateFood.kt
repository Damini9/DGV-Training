package com.example.foodwastemanagement

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.lang.Character.toString
import javax.microedition.khronos.egl.EGLDisplay


class DonateFood : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donate_food)

        // getting view elements

        val name=findViewById<EditText>(R.id.name)
        val phonenumber=findViewById<EditText>(R.id.phonenumber)
        val email=findViewById<EditText>(R.id.email)
        val items=findViewById<EditText>(R.id.fooditems)
        val quantity=findViewById<EditText>(R.id.quantity)
        val address=findViewById<EditText>(R.id.address)
        val donatefood=findViewById<Button>(R.id.donatefood)
        name.requestFocus()

        var helper = MyDBHelper(applicationContext)
        var db=helper.readableDatabase
        var rs=db.rawQuery("SELECT * FROM USERS",null)
//        if (rs.moveToNext())
//            Toast.makeText(applicationContext,rs.getString(1),Toast.LENGTH_LONG).show()
//
//
        // clicking on donate food button submits data to the sqllite database
        donatefood.setOnClickListener {
            var cv = ContentValues()
            cv.put("UNAME",name.text.toString())
            cv.put("PHONE",phonenumber.text.toString())
            cv.put("EMAIL",email.text.toString())
            cv.put("ITEMS",items.text.toString())
            cv.put("QUANTITY",quantity.text.toString())
            cv.put("ADDRESS",address.text.toString())
            db.insert("USERS",null,cv)

//      Showing sucessfully filled after saving data in sqllite
            Toast.makeText(this,"Sucessfully filled",Toast.LENGTH_LONG).show()

        // clearing text after submitting
            name.text.clear()
            phonenumber.text.clear()
            email.text.clear()
            items.text.clear()
            quantity.text.clear()
            address.text.clear()


        }
    }


}




