package com.example.foodwastemanagement

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class RequestFood : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_food)
       /// getting values for of view elements
        val reqname=findViewById<EditText>(R.id.reqname)
        val reqaddress=findViewById<EditText>(R.id.reqaddress)
        val reqphone=findViewById<EditText>(R.id.reqphone)
        val reqbutton = findViewById<Button>(R.id.reqbutton)
        reqname.requestFocus()
        var helper = MyDBHelper2(applicationContext)
        var db2=helper.readableDatabase

    /// clicking on button to submit the form
      reqbutton.setOnClickListener {
          var cv2 = ContentValues()
          cv2.put("NAME",reqname.text.toString())
          cv2.put("ADDRESS",reqaddress.text.toString())
          cv2.put("PHONE",reqphone.text.toString())
          db2.insert("USERS2",null,cv2)

          Toast.makeText(this,"Request Recieved",Toast.LENGTH_LONG).show()
          reqname.text.clear()
          reqaddress.text.clear()
          reqphone.text.clear()
      }
    }
}