package com.example.foodwastemanagement

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
      // getting button
        val gobutton = findViewById<Button>(R.id.gobutton)
     // going to donatefood activity for donating food
        gobutton.setOnClickListener{
            // stating the next activity by clicking on let's go button
            var gointent= Intent(this,Ngos::class.java)
            startActivity(gointent)

        }



    }
}