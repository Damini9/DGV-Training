////package com.example.firstapplication
////
////import androidx.appcompat.app.AppCompatActivity
////import android.os.Bundle
////import android.widget.Button
////import android.widget.EditText
////import android.widget.TextView
//package com.example.firstapplication
//
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.widget.Button
//import android.widget.EditText
//import android.widget.TextView
//import androidx.constraintlayout.widget.ConstraintLayout
//import androidx.lifecycle.ViewModelProvider
//import com.example.firstapplication.R.id.bmiResult
//import com.google.android.material.snackbar.Snackbar
//
//class MainActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//
//        var mainActivityViewModel:MainActivityViewModel=ViewModelProvider(this).get(MainActivityViewModel::class.java)
//
//        val weightInput = findViewById<EditText>(R.id.weightInput)
//        val heightInput = findViewById<EditText>(R.id.heightInput)
//        val clButton = findViewById<Button>(R.id.clButton)
//        val Bmi = findViewById<TextView>(R.id.Bmi)
//        val bmiResult = findViewById<TextView>(R.id.bmiResult)
//        val cl = findViewById<ConstraintLayout>(R.id.cl)
//
//        Bmi.text=mainActivityViewModel.bmi.toInt().toString()
//
//        clButton.setOnClickListener(){
//
//
//            var heightInput = heightInput.text.toString()
//            var weightInput = weightInput.text.toString()
//            if (heightInput != "" && weightInput != "")
//            {
//
//                var heightMeteres = heightInput.toDouble()/100
//                var bmi = weightInput.toDouble()/(heightMeteres*heightMeteres)
//                Bmi.text=bmi.toInt().toString()
//                mainActivityViewModel.changeBmi(bmi)
//                var status:String=""
//
//                when{
//                bmi<18.5 ->{
//                    status="Underweight"
//
//                }
//                bmi>18.5 && bmi<=24 ->
//                {
//                    status="Healthy"
//
//                }
//                bmi >24 && bmi <=28 ->
//                {
//                    status="Overweight"
//                }
//                else->
//                {
//                    status="Obese"
//                }
//               }
//            bmiResult.text=status
//             bmi.text=bmi.toInt().toString()
//           }
//
//
//            else {
//                val snackbar=Snackbar.make(cl, "Missing weight and height",Snackbar.LENGTH_LONG)
//                snackbar.show()
//            }
//
//
//        }
//    }
//}
package com.example.firstapplication

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i("Lifecycle message", "On Create")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var mainActivityViewModel: MainActivityViewModel =
            ViewModelProvider(this).get(MainActivityViewModel::class.java)


        var constraintLayout = findViewById<ConstraintLayout>(R.id.cl)


        val heightInput = findViewById<EditText>(R.id.heightInput)
        val weightInput = findViewById<EditText>(R.id.weightInput)
        val clButton = findViewById<Button>(R.id.clButton)
        val bmiValue = findViewById<TextView>(R.id.bmiValue)
        val bmiResult = findViewById<TextView>(R.id.bmiResult)


        bmiValue.text = mainActivityViewModel.bmi.toInt().toString()

        clButton.setOnClickListener {


            var height = heightInput.text.toString()
            var weight = weightInput.text.toString()

            if (height != "" && weight != "") {


                var heightMeteres = height.toDouble() / 100
                var bmi = (weight.toDouble() / (heightMeteres * heightMeteres))
                mainActivityViewModel.changeBmi(bmi)
                bmiValue.text = mainActivityViewModel.bmi.toInt().toString()

                var status: String = ""
                var color: String = ""
                when {
                    bmi < 18.5 -> {
                        status = "Underweight"
                        color = "#FFE6E620"

                    }
                    bmi >= 18.5 && bmi <= 24.9 -> {
                        status = "Healthy"
                        color = "#34ba34"
                    }
                    bmi >= 25 && bmi <= 29.9 -> {
                        status = "Overweight"
                        color = "#c4491b"
                    }
                    bmi > 29.9 -> {
                        status = "Obese"
                        color = "#d91a1a"
                    }
                }

                bmiResult.setTextColor(Color.parseColor(color))
                bmiResult.text = status.toString()

            } else {
                val snackbar = Snackbar.make(
                    constraintLayout,
                    "Height or Weight Missing",
                    Snackbar.LENGTH_LONG
                )
                snackbar.show()
            }


        }


    }
}







//import androidx.constraintlayout.widget.ConstraintLayout
//import androidx.lifecycle.ViewModelProvider
//import com.google.android.material.snackbar.Snackbar
//
//class MainActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//        var mainActivityViewModel: MainActivityViewModel =ViewModelProvider(this).get(
//            MainActivityViewModel::class.java)
//
//        val constraintLayout=findViewById<ConstraintLayout>(R.id.constraint)
//
//        val weightinput = findViewById<EditText>(R.id.weightinput)
//        val heightinput = findViewById<EditText>(R.id.heightinput)
//        val bmibutton = findViewById<Button>(R.id.bmibutton)
//        val bmicalculate = findViewById<TextView>(R.id.bmicalculate)
//        val bmiresult = findViewById<TextView>(R.id.bmiresult)
//
//        bmibutton.setOnClickListener()
//            {
//                var weight =weightinput.text.toString()
//                var height =heightinput.text.toString()
//
//             if(height!= " " && weight!=" ")
//        {
//            var heightMeters=height.toDouble()/100
//            var bmi=((weight.toDouble()/(heightMeters)*heightMeters))
//            bmicalculate.text=bmi.toInt().toString()
//
//            var status:String=""
//
//            when{
//                bmi<18.5 ->{
//                    status="Underweight"
//
//                }
//                bmi>18.5 && bmi<=24 ->
//                {
//                    status="Healthy"
//
//                }
//                bmi >24 && bmi <=28 ->
//                {
//                    status="Overweight"
//                }
//                else->
//                {
//                    status="Obese"
//                }
//            }
//            bmiresult.text=status
//            bmicalculate.text=bmi.toInt().toString()
//        }
//                else
//             {
//                 val snackbar=Snackbar.make(constraintLayout,"Please enter name",Snackbar.LENGTH_LONG)
////                snackbar.show()
//             }
//        }
//
//
////        val viewName = findViewById<TextView>(R.id.viewName)
//       //val imageView =findViewById<ImageView>(R.id.imageView)
//
////        button.setOnClickListener{
////            val name = userName.text.toString()
////
////            if(name!="")
////            {
////                viewName.text = "Hi $name"
////                userName.text.clear()
////            }
////            else
////            {
//////                val toast=Toast.makeText(applicationContext,"Please enter name",Toast.LENGTH_SHORT)
//////                toast.show()
////                val snackbar=Snackbar.make(constraintLayout,"Please enter name",Snackbar.LENGTH_LONG)
////                snackbar.show()
////            }
////        }
//        //userName.text.clear()
//
//    }
//}