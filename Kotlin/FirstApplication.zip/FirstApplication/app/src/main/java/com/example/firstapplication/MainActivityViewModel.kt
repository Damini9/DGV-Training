package com.example.firstapplication

import androidx.lifecycle.ViewModel


class MainActivityViewModel:ViewModel() {
    var bmi=0.0

    fun changeBmi(bmi:Double)
    {
        this.bmi=bmi
    }
}
